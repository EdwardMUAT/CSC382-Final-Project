Modified from the example at of D3
https://bl.ocks.org/mbostock/4062045

Run the file javascript_force.py to generate the force.json data file needed for this to work.

Then copy all of the files in this directory to a webserver and load force.html.

