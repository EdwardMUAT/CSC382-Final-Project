***********
Sparsifiers
***********

.. automodule:: networkx.algorithms.sparsifiers
.. autosummary::
   :toctree: generated/

   spanner
