************
Broadcasting
************

.. automodule:: networkx.algorithms.broadcasting
.. autosummary::
   :toctree: generated/

   tree_broadcast_center
   tree_broadcast_time
