************
Wiener Index
************

.. automodule:: networkx.algorithms.wiener
.. autosummary::
   :toctree: generated/

   wiener_index
   schultz_index
   gutman_index
