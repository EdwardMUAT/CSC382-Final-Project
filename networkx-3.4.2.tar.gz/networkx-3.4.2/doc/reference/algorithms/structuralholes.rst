****************
Structural holes
****************

.. automodule:: networkx.algorithms.structuralholes
.. autosummary::
   :toctree: generated/

   constraint
   effective_size
   local_constraint
